﻿namespace Lab4N.Models.ViewModels
{
    public class BrokerageSubscriptionsViewModel
    {
        public string BrokerageId { get; set; }
        public string Title { get; set; }
        public bool IsMember { get; set; }
    }

}
