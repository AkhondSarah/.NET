﻿namespace Lab4N.Models.ViewModels
{
    public class DeleteAdsViewModel
    {
        public string Title
        {
            get;
            set;
        }
        public string FileName
        {
            get;
            set;
        }
    }
}
